<?php $__env->startSection('main_content'); ?>


<!-- custom html -->
<header class="header">
    <div class="container">
        <div class="row">
            <div class="span4">
                <div class="profile-img">
                    <img src="img/img-profile.jpg" class="img-responsive" alt="">
                </div>
                <!-- Profile Image -->
            </div>
            <div class="span8">
                <div class="name-wrapper">
                    <h1 class="name"><?php echo e(Auth::user()->name); ?></h1>
                    <span><?php echo e(Auth::user()->email); ?></span>
                </div>
                <p>
                    Hey <?php echo e(Auth::user()->name); ?> !!, Find your SOULMATE, enjoy you life
                </p>


                <div class="row">
                    <div class="span2">
                        <div class="personal-details">
                            <strong><?php echo e(Auth::user()->date_of_birth); ?></strong>
                            <small>BIRTH</small>
                        </div>
                    </div>
                    <div class="span2">
                        <div class="personal-details">
                            <strong><?php echo e(Auth::user()->gender==1 ? 'Male' : 'Femail'); ?></strong>
                            <small>Gender</small>
                        </div>
                    </div>
                    <div class="span4">
                        <div class="personal-details">
                            <strong>ENGLISH <span>(NATIVE)</span>, FRENCH <span>(INTERMEDIATE)</span></strong>
                            <small>LANGUAGE</small>
                        </div>
                    </div>
                </div>

                <ul class="social-icon">
                    <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                    <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                    <li><a href="#"><i class="fa fa-slack" aria-hidden="true"></i></a></li>
                    <li><a href="#"><i class="fa fa-dribbble" aria-hidden="true"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
</header>
<div class="main">
    <div class="main-inner">
        <div class="container">
            <div class="row">

                <div class="span6">

                    <!-- /widget -->
                    <div class="widget">
                        <div class="widget-header"> <i class="icon-file"></i>
                            <h3> This Person Likes You</h3>
                        </div>
                        <!-- /widget-header -->
                        <div class="widget-content">
                            <ul class="messages_layout">
                                <li class="from_user left"> <a href="#" class="avatar"><img src="img/message_avatar1.png"/></a>
                                    <div class="message_wrap"> <span class="arrow"></span>
                                        <div class="info"> <a class="name">John Smith</a> <span class="time">1 hour ago</span>
                                            <div class="options_arrow">
                                                <div class="dropdown pull-right"> <a class="dropdown-toggle " id="dLabel" role="button" data-toggle="dropdown" data-target="#" href="#"> <i class=" icon-caret-down"></i> </a>
                                                    <ul class="dropdown-menu " role="menu" aria-labelledby="dLabel">
                                                        <li><a href="#"><i class=" icon-share-alt icon-large"></i> Reply</a></li>
                                                        <li><a href="#"><i class=" icon-trash icon-large"></i> Delete</a></li>
                                                        <li><a href="#"><i class=" icon-share icon-large"></i> Share</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="text"> As an interesting side note, as a head without a body, I envy the dead. There's one way and only one way to determine if an animal is intelligent. Dissect its brain! Man, I'm sore all over. I feel like I just went ten rounds with mighty Thor. </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <!-- /widget-content -->
                    </div>
                    <!-- /widget -->
                </div>
                <!-- /span6 -->
                <div class="span6">
                    <div class="widget widget-nopad">
                        <div class="widget-header"> <i class="icon-list-alt"></i>
                            <h3> Find Friends</h3>
                        </div>
                        <!-- /widget-header -->
                        <div class="widget-content">
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($user->id!= Auth::user()->id ): ?>
                            <ul class="news-items">


                                <li>

                                    <div class="news-item-date"> <span class="news-item-day">29</span> <span class="news-item-month">Aug</span> </div>
                                    <div class="news-item-detail"> <a  class="news-item-title" target="_blank"><?php echo e($user->name); ?></a>
                                        <p class="news-item-preview">  Email : <?php echo e($user->email); ?></p>
                                        <p class="news-item-preview"> Gender : <?php echo e($user->gender==1? 'Male' : 'Femail'); ?></p>
                                        <p class="news-item-preview">  Date of Birth : <?php echo e($user->date_of_birth); ?> </p>
                                        <p>
                                            <a href="<?php echo e(route('person-detail',['id'=>$user->id])); ?>" class="btn btn-info">View Details</a>
                                               <a href="#" class="btn btn-info"><i class="success fa icon-thumbs-up"></i></a>
                                               &nbsp;   &nbsp;   &nbsp;  &nbsp;  &nbsp;
                                              <a href="#" class="btn btn-warning"><i class="success fa icon-thumbs-down"></i></a>
                                         
                                        <hr>
                                    </div>

                                </li>   

                            </ul>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <!-- /widget-content -->
                    </div>
                    <!-- /widget -->
                </div>
                <!-- /span6 -->
            </div>
            <!-- /row -->
        </div>
        <!-- /container -->
    </div>
    <!-- /main-inner -->
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('front-end.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>