<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Likes extends Model
{
    protected $fillable = ['request_person_id','response_id','request_status','match','dislike'];
}
